import 'package:fire_alarm/mvc/model/user_model.dart';
import 'package:fire_alarm/mvc/services/method_service.dart';
import 'package:flutter/material.dart';

class UserService {
  final _methods = MethodService();

  Future<UserModel> userDetails({required String api}) async {
    final map = await _methods.get(api);
    debugPrint('User Details Response: $map');
    return UserModel.fromJson(map);
  }
}


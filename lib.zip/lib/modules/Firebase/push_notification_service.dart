import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class PushNotificationService {
  static final FirebaseMessaging _fcm = FirebaseMessaging.instance;

  /// Called during app startup
  static Future<void> initialize() async {
    // Ask for permission
    await _requestPermission();

    // Register background handler
    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

    // Listen for messages while app is in foreground
    FirebaseMessaging.onMessage.listen(_handleForegroundMessage);

    // Handle notification taps when app is open or resumed
    FirebaseMessaging.onMessageOpenedApp.listen(_handleNotificationTap);

    // Get device FCM token
    final token = await _fcm.getToken();
    debugPrint('📱 FCM Token (Alert Module): $token');
    // TODO: Send this token to backend if needed (e.g. /users/register_device/)
  }

  /// Request notification permission (Android 13+/iOS)
  static Future<void> _requestPermission() async {
    final settings = await _fcm.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );

    if (settings.authorizationStatus == AuthorizationStatus.authorized) {
      debugPrint('✅ Notification permission granted.');
    } else {
      debugPrint('⚠️ Notification permission denied.');
    }
  }

  /// Handle foreground messages (app open)
  static void _handleForegroundMessage(RemoteMessage message) {
    final title = message.notification?.title ?? 'Fire Alert';
    final body = message.notification?.body ?? 'Check your alerts.';

    Get.snackbar(
      title,
      body,
      backgroundColor: Colors.deepOrangeAccent,
      colorText: Colors.white,
      snackPosition: SnackPosition.TOP,
      margin: const EdgeInsets.all(16),
      duration: const Duration(seconds: 4),
    );
  }

  /// Handle notification tap (user opens app via notification)
  static void _handleNotificationTap(RemoteMessage message) {
    final data = message.data;
    debugPrint('📬 Notification tapped: $data');

    // If backend sends { "screen": "alerts" }
    final screen = data['screen'];
    if (screen == 'alerts') {
      Get.toNamed('/alerts'); // Go to alert page
    }
  }

  /// Handle background messages (app closed)
  static Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
    debugPrint('🕓 Background message received: ${message.notification?.title}');
  }
}

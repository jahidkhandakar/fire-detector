import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import '/modules/Firebase/fcm_service.dart';
import '/modules/Alerts/alert_controller.dart';
import '/others/utils/api.dart';

class PushNotificationService {
  static final FirebaseMessaging _fcm = FirebaseMessaging.instance;
  static final FlutterLocalNotificationsPlugin _local =
      FlutterLocalNotificationsPlugin();

  static Future<void> initialize() async {
    // 🔹 Request notification permissions
    await _fcm.requestPermission();

    // 🔹 Local notification setup
    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const initSettings = InitializationSettings(android: androidSettings);
    await _local.initialize(initSettings);

    // 🔹 Register device token with backend
    final token = await _fcm.getToken();
    if (token != null) {
      debugPrint('📲 FCM Token: $token');
      await FcmService().registerDeviceToken(token);
    }

    // 🔹 Handle incoming foreground messages
    FirebaseMessaging.onMessage.listen((RemoteMessage message) async {
      final title = message.notification?.title ?? '🔥 Fire Alert';
      final body = message.notification?.body ?? 'Smoke detected!';
      final data = message.data;

      debugPrint('🔥 FCM ALERT RECEIVED:');
      debugPrint('Title: $title');
      debugPrint('Body: $body');
      debugPrint('Data: $data');

      // ✅ Show in-app GetX snackbar
      Get.snackbar(
        title,
        body,
        snackPosition: SnackPosition.TOP,
        backgroundColor: Colors.red.shade700,
        colorText: Colors.white,
        icon: const Icon(Icons.warning_amber_rounded, color: Colors.white),
        duration: const Duration(seconds: 5),
      );

      // ✅ Show a local notification in system tray
      await _showLocalNotification(message);

      // ✅ Auto-refresh AlertPage if user is currently viewing it
      if (Get.currentRoute == '/alerts') {
        try {
          final alertController = Get.find<AlertController>();
          await alertController.loadAlerts(apiUrl: Api.alerts);
          debugPrint('🔁 Alerts reloaded after FCM notification');
        } catch (e) {
          debugPrint('⚠️ Could not reload alerts: $e');
        }
      }
    });

    // 🔹 Handle notification taps (when app opened from background)
    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      debugPrint('🔔 Notification opened → ${message.data}');
      Get.toNamed('/alerts');
    });
  }

  // 🔹 Display a local notification
  static Future<void> _showLocalNotification(RemoteMessage message) async {
    const androidDetails = AndroidNotificationDetails(
      'alerts_channel',
      'Fire Alerts',
      channelDescription: 'Notifications for fire or smoke alerts',
      importance: Importance.max,
      priority: Priority.high,
      playSound: true,
      enableVibration: true,
    );

    const details = NotificationDetails(android: androidDetails);

    await _local.show(
      0,
      message.notification?.title ?? 'Fire Alarm',
      message.notification?.body ?? 'You have a new alert',
      details,
    );
  }
}

import '/others/utils/api.dart';
import '../../mvc/services/method_service.dart';
import '/modules/alerts/alert_model.dart';


class AlertService {
  final MethodService _method = MethodService();

  Future<List<AlertModel>> fetchAlerts({int page = 1}) async {
    final url = '${Api.baseUrl}/alerts/?page=$page';
    final res = await _method.get(url);

    if (res.isEmpty) return [];

    final results = res['results'] as List<dynamic>? ?? [];
    return results.map((e) => AlertModel.fromJson(e)).toList();
  }

  Future<AlertModel?> getAlertById(int id) async {
    final url = '${Api.baseUrl}/alerts/$id/';
    final res = await _method.get(url);
    if (res.isEmpty) return null;
    return AlertModel.fromJson(res);
  }

  Future<bool> resolveAlert(int id) async {
    final url = '${Api.baseUrl}/alerts/$id/resolve/';
    final res = await _method.post(url, {});
    return res['statusCode'] == 200;
  }

  Future<List<AlertModel>> getDeviceAlerts(int deviceId) async {
    final url = '${Api.baseUrl}/devices/$deviceId/alerts/';
    final res = await _method.get(url);
    if (res.isEmpty) return [];
    final results = res['results'] as List<dynamic>? ?? [];
    return results.map((e) => AlertModel.fromJson(e)).toList();
  }
}

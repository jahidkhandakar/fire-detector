import '/modules/Alerts/alert_service.dart';
import '/modules/alerts/alert_model.dart';
import 'package:get/get.dart';

class AlertController extends GetxController {
  final AlertService _service = AlertService();

  var alerts = <AlertModel>[].obs;
  var isLoading = false.obs;

  Future<void> loadAlerts({int page = 1}) async {
    try {
      isLoading.value = true;
      final list = await _service.fetchAlerts(page: page);
      alerts.assignAll(list);
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> resolveAlert(int id) async {
    final success = await _service.resolveAlert(id);
    if (success) {
      alerts.removeWhere((a) => a.id == id);
      await loadAlerts(); // refresh list
    }
  }
}

import '/modules/alerts/alert_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class AlertPage extends StatelessWidget {
  AlertPage({super.key});
  final AlertController controller = Get.put(AlertController());

  @override
  Widget build(BuildContext context) {
    controller.loadAlerts();
    return Scaffold(
      appBar: AppBar(title: const Text("Alerts")),
      body: Obx(() {
        if (controller.isLoading.value) {
          return const Center(child: CircularProgressIndicator());
        }
        if (controller.alerts.isEmpty) {
          return const Center(child: Text("No alerts found."));
        }
        return ListView.builder(
          itemCount: controller.alerts.length,
          itemBuilder: (context, index) {
            final alert = controller.alerts[index];
            return Card(
              margin: const EdgeInsets.all(8),
              child: ListTile(
                title: Text(alert.alertType),
                subtitle: Text(
                    "Device: ${alert.deviceHardwareIdentifier}\nStatus: ${alert.status}"),
                trailing: IconButton(
                  icon: const Icon(Icons.check_circle_outline),
                  onPressed: () => controller.resolveAlert(alert.id),
                ),
              ),
            );
          },
        );
      }),
    );
  }
}

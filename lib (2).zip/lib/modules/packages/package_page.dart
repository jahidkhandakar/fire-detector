import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import '/modules/packages/package_controller.dart';
import '/modules/packages/package_model.dart';
import '/modules/users/user_controller.dart';
import '/modules/cart/cart_controller.dart';
import '/others/utils/api.dart';
import '/others/widgets/package_selector.dart';

class PackagePage extends StatefulWidget {
  const PackagePage({super.key});

  @override
  State<PackagePage> createState() => _PackagePageState();
}

class _PackagePageState extends State<PackagePage> {
  final PackageController _pkgCtrl = Get.put(PackageController());
  final UserController _userCtrl =
      Get.put(UserController(), permanent: true);

  late final CartController _cartCtrl;

  final String apiUrl = Api.packages;
  final _currency = NumberFormat.currency(locale: 'en_BD', symbol: '৳');

  final Map<int, int> masterQtyByPackage = {};
  final Map<int, int> slaveQtyByPackage = {};

  @override
  void initState() {
    super.initState();

    _cartCtrl = Get.isRegistered<CartController>()
        ? Get.find<CartController>()
        : Get.put(CartController(), permanent: true);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_pkgCtrl.packages.isEmpty && !_pkgCtrl.isLoading.value) {
        _pkgCtrl.loadPackages(apiUrl: apiUrl);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Obx(() {
        if (_pkgCtrl.isLoading.value) {
          return const Center(child: CircularProgressIndicator());
        }
        if (_pkgCtrl.error.isNotEmpty) {
          return Center(child: Text(_pkgCtrl.error.value));
        }
        if (_pkgCtrl.packages.isEmpty) {
          return const Center(child: Text('No packages available.'));
        }

        return RefreshIndicator(
          onRefresh: () => _pkgCtrl.loadPackages(apiUrl: apiUrl),
          child: ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: _pkgCtrl.packages.length,
            itemBuilder: (context, index) {
              final pkg = _pkgCtrl.packages[index];

              final bool isStandalone = index == 1;

              return _buildPackageCard(pkg, isStandalone: isStandalone);
            },
          ),
        );
      }),
    );
  }

  Widget _buildPackageCard(PackageModel pkg, {required bool isStandalone}) {
    final masters = masterQtyByPackage[pkg.id] ?? pkg.minQuantity;
    final slaves =
        isStandalone ? 0 : (slaveQtyByPackage[pkg.id] ?? pkg.minQuantity);

    final devices = masters + slaves;
    final upfrontDevicesCost = pkg.pricePerDevice * devices;
    final firstMonthMrf = pkg.mrf * masters; // MRF only on masters
    final totalNow = upfrontDevicesCost + firstMonthMrf;

    return Card(
      elevation: 4,
      margin: const EdgeInsets.symmetric(vertical: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    _titleCase(
                      pkg.name.isEmpty ? 'Unnamed Package' : pkg.name,
                    ),
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.blue[800],
                    ),
                  ),
                ),
                _rangeChip(pkg.minQuantity, pkg.maxQuantity),
              ],
            ),
            const SizedBox(height: 8),
            const Divider(height: 20),

            _rowIconTextValue(
              icon: Icons.sell,
              label: 'Price / Device',
              value: _currency.format(pkg.pricePerDevice),
            ),
            const SizedBox(height: 10),
            _rowIconTextValue(
              icon: Icons.autorenew,
              label: 'MRF (per master)',
              value: pkg.mrf == 0 ? '—' : _currency.format(pkg.mrf),
            ),

            const SizedBox(height: 14),
            const Divider(height: 20),

            Center(
              child: Text(
                "How many devices do you need?",
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.grey[800],
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            const SizedBox(height: 18),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Master selector
                Column(
                  children: [
                    Text(
                      "Master",
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.grey[800],
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 2),
                    PackageSelector(
                      min: pkg.minQuantity,
                      max: pkg.maxQuantity,
                      initial: masters,
                      onChanged: (v) =>
                          setState(() => masterQtyByPackage[pkg.id] = v),
                    ),
                  ],
                ),
                const SizedBox(width: 16),
                // Slave selector
                if (!isStandalone) ...[
                  Column(
                    children: [
                      Text(
                        "Slave",
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.grey[800],
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 2),
                      PackageSelector(
                        min: pkg.minQuantity,
                        max: pkg.maxQuantity,
                        initial: slaves,
                        onChanged: (v) =>
                            setState(() => slaveQtyByPackage[pkg.id] = v),
                      ),
                    ],
                  ),
                ],
              ],
            ),

            const SizedBox(height: 12),
            Center(
              child: Text(
                isStandalone
                    ? 'Selected: $masters Master device(s)'
                    : 'Selected: $masters Master • $slaves Slave',
                style: TextStyle(
                  color: Colors.grey[700],
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            const SizedBox(height: 8),
            Center(
              child: Text(
                'First month MRF (masters only): '
                '${firstMonthMrf == 0 ? "—" : _currency.format(firstMonthMrf)}',
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                  color: Colors.grey[800],
                ),
              ),
            ),
            const SizedBox(height: 4),
            Center(
              child: Text(
                'Total Price: ${_currency.format(totalNow)}',
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w800,
                  color: Colors.black,
                ),
              ),
            ),

            const SizedBox(height: 14),
            const Divider(height: 20),

            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton.icon(
                  onPressed: () => _showPackageDetails(pkg),
                  icon: const Icon(Icons.info_outline),
                  label: const Text('Details'),
                ),
                const SizedBox(width: 8),
                FilledButton.icon(
                  onPressed: () => _handleSelect(
                    pkg,
                    masters,
                    isStandalone ? 0 : slaves,
                    totalNow,
                  ),
                  icon: const Icon(Icons.add_shopping_cart),
                  label: const Text('Add to cart'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _handleSelect(
    PackageModel pkg,
    int masters,
    int slaves,
    double totalNow,
  ) async {
    if (totalNow <= 0) {
      Get.snackbar('Cart', 'Amount must be greater than 0');
      return;
    }

    final userId = _userCtrl.getStoredUserId();
    if (userId == null) {
      Get.snackbar('Cart', 'Please login first');
      return;
    }

    final devices = masters + slaves;
    if (devices <= 0) {
      Get.snackbar('Cart', 'Select at least 1 device');
      return;
    }

    debugPrint(
      '🛒 _handleSelect pkg=${pkg.id} masters=$masters slaves=$slaves devices=$devices totalNow=$totalNow',
    );

    try {
      await _cartCtrl.addPackageToCart(
        pkg: pkg,
        masters: masters,
        slaves: slaves,
      );

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Added ${_titleCase(pkg.name)} to cart.',
          ),
          duration: const Duration(seconds: 2),
        ),
      );
    } catch (_) {
      final msg =
          _cartCtrl.error.value.isNotEmpty
              ? _cartCtrl.error.value
              : 'Failed to add item to cart.';
      Get.snackbar('Cart', msg);
    }
  }

  //________________________HELPERS________________________//

  Widget _rowIconTextValue({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Row(
      children: [
        Icon(icon, size: 18, color: Colors.black54),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            label,
            style: TextStyle(
              color: Colors.grey[800],
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        Text(
          value,
          style: const TextStyle(
            fontSize: 16,
            color: Colors.black87,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }

  Widget _rangeChip(int minQ, int maxQ) {
    return Chip(
      label: Text('Qty: $minQ–$maxQ'),
      avatar: const Icon(
        Icons.format_list_numbered,
        size: 16,
        color: Colors.white,
      ),
      labelStyle: const TextStyle(color: Colors.white),
      backgroundColor: Colors.blueAccent,
      visualDensity: VisualDensity.compact,
      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
    );
  }

  void _showPackageDetails(PackageModel pkg) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) {
        return Padding(
          padding: const EdgeInsets.all(16),
          child: SingleChildScrollView(
            child: Column(
              children: [
                Container(
                  width: 50,
                  height: 5,
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  _titleCase(pkg.name),
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                _kvRow('ID', pkg.id.toString()),
                _kvRow(
                  'Quantity Range',
                  '${pkg.minQuantity} – ${pkg.maxQuantity}',
                ),
                _kvRow(
                  'Price per Device',
                  _currency.format(pkg.pricePerDevice),
                ),
                _kvRow(
                  'MRF (per master)',
                  pkg.mrf == 0 ? '—' : _currency.format(pkg.mrf),
                ),
                const SizedBox(height: 16),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _kvRow(String k, String v) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Expanded(
            flex: 3,
            child: Text(
              '$k:',
              style: const TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 15,
                color: Colors.black87,
              ),
            ),
          ),
          Expanded(
            flex: 5,
            child: Text(
              v,
              textAlign: TextAlign.end,
              style: const TextStyle(fontSize: 15, color: Colors.black54),
            ),
          ),
        ],
      ),
    );
  }

  String _titleCase(String s) {
    if (s.isEmpty) return s;
    return s
        .split(' ')
        .map((w) => w.isEmpty ? w : '${w[0].toUpperCase()}${w.substring(1)}')
        .join(' ');
  }
}
